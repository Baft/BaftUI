## Contributing

<div class="summary">You can and should contribute.</div>

Scut is all about easing the work of frontend laborers; extending tutorials into reusable utilities; encouraging best practices; and sharing good ideas &mdash; goals we can all agree on. I hope you'll find it a worthy experiment.

<a href="{{github-home}}">Visit the repository on Github</a> and file issues and pull requests according to the usual Github methods. A little contribution guide is included in the README there.