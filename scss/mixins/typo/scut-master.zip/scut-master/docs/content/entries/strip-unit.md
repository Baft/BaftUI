---
name: strip unit
slug: strip-unit
summary: Strip the unit from a number.
type: function
categories:
  - functions
args:
  - variable: $num
    comment: The number whose units you wish to strip.
---

This becomes useful when you are building your own mixins and functions and find yourself in an error-littered tangle of units. With this function you can just ditch those units, then put them back later.

No example necessary.