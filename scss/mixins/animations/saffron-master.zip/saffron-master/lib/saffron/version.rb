module Saffron
  VERSION = "0.2.2"
end
