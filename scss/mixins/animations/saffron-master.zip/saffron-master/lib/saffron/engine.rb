module Saffron
  class Engine < Rails::Engine
  end
end
